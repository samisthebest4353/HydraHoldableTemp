﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MelonLoader;
using UnityEngine.UI;
using UnityEngine;
using WristMenu;
using static MelonLoader.MelonLogger;
using easyInputs;
using Photon.Pun;

namespace Hydras_Testing
{
    public class Class1 : MelonMod
    {
        // This Menu Template Was Built From https://github.com/jeydevv/MonkeModMenu

        // Setup Buttons
        //-----------------
        public static string[] buttons = new string[] { "Disconnect", "Placeholder", "Placeholder", "Placeholder", "Placeholder", "Placeholder" };
        public static string[] buttons2 = new string[] { "Join Random", "Placeholder", "Placeholder", "Placeholder", "Placeholder", "Placeholder" };
        public static bool?[] buttonsActive = new bool?[] { false, false, false, false, false, false };
        public static bool?[] buttonsActive2 = new bool?[] { false, false, false, false, false, false };

        public static int maxPage = 2; // Change Max Page To Your Maximum Page Number

        // Actual Menu Setup
        //-----------------
        public static string menuName = "MENU NAME HERE";
        public static Color menuColor = Color.black;
        public static Color onColor = Color.red;
        public static Color offColor = Color.black;

        //--------------------
        // No Change Needed
        //--------------------
        public static int page = 1;
        public static GameObject menu = null;
        public static GameObject canvasObj = null;
        public static GameObject referance = null;
        public static int framePressCooldown = 0;
        public static bool canClickR = true;
        public static bool canClickL = true;
        //--------------------


        public override void OnUpdate()
        {
            if (EasyInputs.GetSecondaryButtonDown(EasyHand.LeftHand) && menu == null)
            {
                Draw();
                if (referance == null)
                {
                    referance = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    GameObject.Destroy(referance.GetComponent<SphereCollider>());
                    referance.transform.parent = GorillaLocomotion.Player.Instance.rightHandTransform;
                    referance.transform.localPosition = new Vector3(0f, 0f, 0.1f);
                    referance.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
                }
            }
            else if (!EasyInputs.GetSecondaryButtonDown(EasyHand.LeftHand) && menu != null)
            {
                GameObject.Destroy(menu);
                menu = null;
                GameObject.Destroy(referance);
                referance = null;
            }

            if (EasyInputs.GetSecondaryButtonDown(EasyHand.LeftHand) && menu != null)
            {
                CheckButtons();
                menu.transform.position = GorillaLocomotion.Player.Instance.leftHandTransform.position;
                menu.transform.rotation = GorillaLocomotion.Player.Instance.leftHandTransform.rotation;

                if (EasyInputs.GetTriggerButtonDown(EasyHand.RightHand))
                {
                    if (canClickR)
                    {
                        page++;
                        canClickR = false;
                    }
                }
                else
                {
                    canClickR = true;
                }

                if (EasyInputs.GetTriggerButtonDown(EasyHand.LeftHand))
                {
                    if (canClickL)
                    {
                        page--;
                        canClickL = false;
                    }
                }
                else
                {
                    canClickL = true;
                }
            }

            // Page Fixer
            if (page < 1)
            {
                page = maxPage;
            }

            if (page > maxPage)
            {
                page = 1;
            }
            

            // Buttons Actual

            // Page 1
            if (buttonsActive[0] == true)
            {
                PhotonNetwork.Disconnect();
            }

            // Page 2
            if (buttonsActive2[0] == true)
            {
                PhotonNetwork.JoinRandomRoom();
            }
        }

        public static void CheckButtons()
        {
            // Dupe Then Change Page == Then The Next Page
            // Also Add Buttons Then Ur Page Number
            if (page == 1)
            {
                for (int i = 0; i < buttons.Length; i++)
                {
                    AddButton(i * 0.13f, buttons[i]);
                }
            }

            if (page == 2)
            {
                for (int i = 0; i < buttons2.Length; i++)
                {
                    AddButton(i * 0.13f, buttons2[i]);
                }
            }
        }

        public static void AddButton(float offset, string text)
        {
            // Just Change Buttons And ButtonsActive To Your Page Number
            if (page == 1)
            {
                GameObject newBtn = GameObject.CreatePrimitive(PrimitiveType.Cube);
                GameObject.Destroy(newBtn.GetComponent<Rigidbody>());
                newBtn.GetComponent<BoxCollider>().isTrigger = true;
                newBtn.transform.parent = menu.transform;
                newBtn.transform.rotation = menu.transform.rotation;
                newBtn.transform.localScale = new Vector3(0.09f, 0.8f, 0.08f);
                newBtn.transform.localPosition = new Vector3(0.56f, 0f, 0.28f - offset);
                Hydras_Testing.FixedColliders.relatedText = text;
                Hydras_Testing.FixedColliders.reference = referance;
                Hydras_Testing.FixedColliders.button = newBtn;
                Hydras_Testing.FixedColliders.CheckButton();

                int index = -1;
                for (int i = 0; i < buttons.Length; i++)
                {
                    if (text == buttons[i])
                    {
                        index = i;
                        break;
                    }
                }

                if (buttonsActive[index] == false)
                {
                    newBtn.GetComponent<Renderer>().material.SetColor("_Color", offColor);
                }
                else if (buttonsActive[index] == true)
                {
                    newBtn.GetComponent<Renderer>().material.SetColor("_Color", onColor);
                }
                else
                {
                    newBtn.GetComponent<Renderer>().material.SetColor("_Color", Color.grey);
                }

                GameObject titleObj = new GameObject();
                titleObj.transform.parent = canvasObj.transform;
                Text title = titleObj.AddComponent<Text>();
                title.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                title.text = text;
                title.fontSize = 1;
                title.alignment = TextAnchor.MiddleCenter;
                title.resizeTextForBestFit = true;
                title.resizeTextMinSize = 0;
                RectTransform titleTransform = title.GetComponent<RectTransform>();
                titleTransform.localPosition = Vector3.zero;
                titleTransform.sizeDelta = new Vector2(0.2f, 0.03f);
                titleTransform.localPosition = new Vector3(0.064f, 0f, 0.111f - (offset / 2.55f));
                Quaternion newRotation = newBtn.transform.rotation * Quaternion.Euler(180f, 90f, 90f);
                titleTransform.rotation = newRotation;
                GameObject.Destroy(newBtn, Time.deltaTime);
                GameObject.Destroy(titleObj, Time.deltaTime);
            }

            if (page == 2)
            {
                GameObject newBtn = GameObject.CreatePrimitive(PrimitiveType.Cube);
                GameObject.Destroy(newBtn.GetComponent<Rigidbody>());
                newBtn.GetComponent<BoxCollider>().isTrigger = true;
                newBtn.transform.parent = menu.transform;
                newBtn.transform.rotation = menu.transform.rotation;
                newBtn.transform.localScale = new Vector3(0.09f, 0.8f, 0.08f);
                newBtn.transform.localPosition = new Vector3(0.56f, 0f, 0.28f - offset);
                Hydras_Testing.FixedColliders.relatedText = text;
                Hydras_Testing.FixedColliders.reference = referance;
                Hydras_Testing.FixedColliders.button = newBtn;
                Hydras_Testing.FixedColliders.CheckButton();

                int index = -1;
                for (int i = 0; i < buttons2.Length; i++)
                {
                    if (text == buttons2[i])
                    {
                        index = i;
                        break;
                    }
                }

                if (buttonsActive2[index] == false)
                {
                    newBtn.GetComponent<Renderer>().material.SetColor("_Color", offColor);
                }
                else if (buttonsActive2[index] == true)
                {
                    newBtn.GetComponent<Renderer>().material.SetColor("_Color", onColor);
                }
                else
                {
                    newBtn.GetComponent<Renderer>().material.SetColor("_Color", Color.grey);
                }

                GameObject titleObj = new GameObject();
                titleObj.transform.parent = canvasObj.transform;
                Text title = titleObj.AddComponent<Text>();
                title.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                title.text = text;
                title.fontSize = 1;
                title.alignment = TextAnchor.MiddleCenter;
                title.resizeTextForBestFit = true;
                title.resizeTextMinSize = 0;
                RectTransform titleTransform = title.GetComponent<RectTransform>();
                titleTransform.localPosition = Vector3.zero;
                titleTransform.sizeDelta = new Vector2(0.2f, 0.03f);
                titleTransform.localPosition = new Vector3(0.064f, 0f, 0.111f - (offset / 2.55f));
                Quaternion newRotation = newBtn.transform.rotation * Quaternion.Euler(180f, 90f, 90f);
                titleTransform.rotation = newRotation;
                GameObject.Destroy(newBtn, Time.deltaTime);
                GameObject.Destroy(titleObj, Time.deltaTime);
            }
        }

        public static void Toggle(string relatedText)
        {
            // Dupe Then Just Change Buttons And ButtonActive To Your Page
            if (page == 1)
            {
                int index = -1;
                for (int i = 0; i < buttons.Length; i++)
                {
                    if (relatedText == buttons[i])
                    {
                        index = i;
                        break;
                    }
                }

                if (buttonsActive[index] != null)
                {
                    buttonsActive[index] = !buttonsActive[index];

                    GameObject.Destroy(menu);
                    menu = null;
                    Draw();
                }
            }

            if (page == 2)
            {
                int index = -1;
                for (int i = 0; i < buttons2.Length; i++)
                {
                    if (relatedText == buttons2[i])
                    {
                        index = i;
                        break;
                    }
                }

                if (buttonsActive2[index] != null)
                {
                    buttonsActive2[index] = !buttonsActive2[index];

                    GameObject.Destroy(menu);
                    menu = null;
                    Draw();
                }
            }
        }

        public static void Draw()
        {
            menu = GameObject.CreatePrimitive(PrimitiveType.Cube);
            GameObject.Destroy(menu.GetComponent<Rigidbody>());
            GameObject.Destroy(menu.GetComponent<BoxCollider>());
            GameObject.Destroy(menu.GetComponent<Renderer>());
            menu.transform.localScale = new Vector3(0.1f, 0.3f, 0.4f);

            GameObject background = GameObject.CreatePrimitive(PrimitiveType.Cube);
            GameObject.Destroy(background.GetComponent<Rigidbody>());
            GameObject.Destroy(background.GetComponent<BoxCollider>());
            background.transform.parent = menu.transform;
            background.transform.rotation = Quaternion.identity;
            background.transform.localScale = new Vector3(0.1f, 1f, 1f);
            background.GetComponent<Renderer>().material.SetColor("_Color", menuColor);
            background.transform.position = new Vector3(0.05f, 0f, 0f);

            canvasObj = new GameObject();
            canvasObj.transform.parent = menu.transform;
            Canvas canvas = canvasObj.AddComponent<Canvas>();
            CanvasScaler canvasScale = canvasObj.AddComponent<CanvasScaler>();
            canvasObj.AddComponent<GraphicRaycaster>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasScale.dynamicPixelsPerUnit = 1000;

            GameObject titleObj = new GameObject();
            titleObj.transform.parent = canvasObj.transform;
            Text title = titleObj.AddComponent<Text>();
            title.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            title.text = menuName;
            title.fontSize = 1;
            title.alignment = TextAnchor.MiddleCenter;
            title.resizeTextForBestFit = true;
            title.resizeTextMinSize = 0;
            RectTransform titleTransform = title.GetComponent<RectTransform>();
            titleTransform.localPosition = Vector3.zero;
            titleTransform.sizeDelta = new Vector2(0.28f, 0.05f);
            titleTransform.position = new Vector3(0.06f, 0f, 0.175f);
            titleTransform.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
        }
    }
}
