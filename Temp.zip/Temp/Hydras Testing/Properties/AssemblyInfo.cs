﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using MelonLoader;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: MelonInfo(typeof(Hydras_Testing.Class1), "HydrasFixedTemp", "1.0.0", "HydrasFixedTemp", "")]
[assembly: MelonGame(null, null)]
[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("18868-13842")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright © 18868-13842 2023")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("ca8c2ec1-a3f9-4480-bd57-ed61addb5e25")]
[assembly: AssemblyFileVersion("1.0.0.0")]
