﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MelonLoader;
using UnityEngine.UI;
using UnityEngine;
using Hydras_Testing;

namespace Hydras_Testing
{
    public class FixedColliders
    {
        public static string relatedText;
        public static GameObject reference;
        public static GameObject button;
        public static void CheckButton()
        {
            float distanceButton = Vector3.Distance(button.transform.position, reference.transform.position);

            if (Time.frameCount >= Class1.framePressCooldown + 30 && distanceButton <= 0.02)
            {
                Class1.Toggle(relatedText);
                Class1.framePressCooldown = Time.frameCount;
            }
        }
    }
}
